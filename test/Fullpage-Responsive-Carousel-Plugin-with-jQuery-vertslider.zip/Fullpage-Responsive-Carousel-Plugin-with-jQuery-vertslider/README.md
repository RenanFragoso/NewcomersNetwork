jquery.vertslider
=================
Responsive full page vertical slider
-------------------------------------


Run index.html for a DEMO

HOW-TO-USE:
-----------

1. Add vertslider.css and navigation.css to your <head>

2. Add JQuery to your ```<head>```

3. Add ```<script src="jquery.vertslider.js"></script>``` at the bottom of the ```<body>```

4. Place the Images folder in the same folder as vertslider.css and navigation.css

5. Add ```<div id="vertslider-wrapper"> </div>``` as a child element of your body

6. Add a new page to the slider by adding a ```<section class="vertslider-page-wrapper">PAGE CONTENT HERE</section>``` as a child element of ```<div id="vertslider-wrapper">``` like this: ```<div id="vertslider-wrapper"> <section class="vertslider-page-wrapper">PAGE CONTENT HERE</section> </div>```

7. Done!
